import bskGame                                  # 생성한 모듈
import pyautogui                                # 실행 창 화면 초기화 모듈


play = bskGame.Game()                           # 모듈 불러오기
turn = 0                                        # 공수
while True:
    choice = input("1:게임규칙 \n2:게임시작\n입력:")

    if choice == "1":                           # 게임 규칙
        choice = 1
        play.Manual()                           # bskGame.py 모듈 Manual 함수 import
        choice -= 1
        continue

    elif choice == "2":                          # 게임 시작
        pyautogui.press(";")                     # 실행창 초기화
        print("난이도를 선택하세요 \n1:쉬움 2:어려움")
        choice = input("입력: ")                  # 난이도 선택

        if choice == "1":                        # 난이도 쉬움
            while True:
                pyautogui.press(";")
                print("차례를 정하세요. ex)1:선공 2:후공")
                choice1 = input("입력: ")
                if choice1 == "1":                # 선공
                    break
                elif choice1 == "2":              # 후공
                    turn += 1
                    break
                else:                             # 1, 2 이외 str, int 입력 시 이전 실행 창으로 이동
                    pyautogui.press(";")
                    print("다시입력하세요!")
                    continue

            while True:                           # 게임 실행
                if turn == 0:
                    play.Player()                 # bskGame.py 모듈 Player 함수 import
                    turn += 1
                elif turn == 1:
                    play.Computer_easy_mode()     # bskGame.py 모듈 Computer_easy_mode 함수 import
                    turn -= 1

                if play.num >= 32:                # 게임 종료
                    break

        elif choice == "2":                       # 난이도 어려움
            while True:
                pyautogui.press(";")
                print("차례를 정하세요. ex)1:선공 2:후공")
                choice1 = input("입력: ")
                if choice1 == "1":                 # 선공
                    break
                elif choice1 == "2":               # 후공
                    turn += 1
                    break
                else:                              # 1, 2 이외 str, int 입력 시 이전 실행 창으로 이동
                    pyautogui.press(";")
                    print("다시입력하세요!")
                    continue

            while True:                             # 게임 실행
                if turn == 0:
                    play.Player()                   # bskGame.py 모듈 Player 함수 import
                    turn += 1
                elif turn == 1:
                    play.Computer_hard_mode()       # bskGame.py 모듈 Computer_hard_mode 함수 import
                    turn -= 1
                if play.num >= 32:                  # 게임 종료
                    break

        else:                                       # 1, 2 이외 str, int 입력 시 이전 실행 창으로 이동
            print("다시입력하세요!")
    else:                                           # 1, 2 이외 str, int 입력 시 이전 실행 창으로 이동
        print("다시입력하세요!")

    if play.num >= 31:                              # 게임 종료
        break

if turn == 0:                                       # 플레이어 승리
    print("플레이어 승리!!")
    play.Image_win()                                # bskGame.py 모듈 Image_win 함수 import
else:                                               # 컴퓨터 승리
    print("컴퓨터 승리...")
    play.Image_lose()                               # bskGame.py 모듈 Image_lose 함수 import
import random                                                               # random 모듈 randint 함수 활용(입력한 숫자 두개의 범위에 숫자 임의로 추출 ex) (1,3) = 1이상 3이하)
from PIL import Image as img                                                # Pillow 모듈 의 Image 함수 활용(저장된 이미지를 불러오는 함수)

class Game:
    def __init__(self):
        self.total = []                                                     # 게임 진행 간 입력 받은 숫자 저장을 위해 리스트 생성
        self.num = 1                                                        # 진행 되는 게임 숫자 정의


    def Manual(self):                                                       # 설명서
        print("게임의 참여자는 차례를 정한뒤 1~3 까지 부를 숫자의 범위를 입력하여 "
              "\n마지막에 숫자 범위가 31을 넘어가는 쪽이 게임에서 진다.")

    def Image_win(self):                                                    # 이미지 불러오기(승리)
        image_win = img.open("./images/win.png")
        image_win.show()

    def Image_lose(self):                                                   # 이미지 불러오기(패배)
        image_lose = img.open("./images/lose.png")
        image_lose.show()

    def Player(self):                                                       # 플레이어
        while True:                                                         # 요구 한 숫자 이외 문자 및 숫자를 입력 했을 시 프로그램 종료를 막기 위해 반복문 활용
            print("\n\n---------플레이어 차례!!-----------")
            print("부를 갯수를 입력하세요! ex)1~3")
            self.player = input("입력: ")                                    # 플레이어 입력
            if self.player == "1":                                          # str "1" 입력시
                self.player = 1                                             # int 1 로 변환
                self.total.append(self.num)                                 # 정의 한 변수(num)를 리스트에 저장
                self.num += self.player                                     # 입력 받은 숫자 만큼 정의 한 변수(num)에 더하기
                print(self.total[-self.player:])                            # 입력 받은 범위 내 숫자 출력
                break
            elif self.player == "2":                                        # str "2" 입력시
                self.player = 2                                             # int 2 로 변환
                for i in range(self.player):                                # 반복문 활용을 활용 하여 변환된 숫자 만큼 반복
                    self.total.append(self.num)                             # 정의 한 변수(num)를 리스트에 반복 저장
                    self.num += 1                                           # 반복하는 횟수 만큼 정의 한 변수(num)에 더하기
                print(self.total[-self.player:])                            # 입력 받은 범위 내 숫자 출력
                break
            elif self.player == "3":                                        # str "3" 입력시
                self.player = 3                                             # int 2 로 변환
                for i in range(self.player):                                # 반복문 활용을 활용 하여 변환된 숫자 만큼 반복
                    self.total.append(self.num)                             # 정의 한 변수(num)를 리스트에 반복 저장
                    self.num += 1                                           # 반복하는 횟수 만큼 정의 한 변수(num)에 더하기
                print(self.total[-self.player:])                            # 입력 받은 범위 내 숫자 출력
                break
            else:                                                           # str '1', '2', '3' 이외 숫자 입력 시 이전 실행 창으로 이동
                print("다시입력하세요!")
                continue
        return self.total, self.num                                         # 저장 된 리스트 및 함수 return

    def Computer_easy_mode(self):                                           # 컴퓨터(쉬움)
        print('\n\n----------컴퓨터 차례!!------------')
        self.computer = random.randint(1, 3)                                # random 모듈 randint 함수를 활용하여 1이상 3이하 숫자를 프로그램이 임의로 선택
        for a in range(self.computer):                                      # 반복문 활용을 활용 하여 프로그램이 선택한 숫자 만큼 반복
            self.total.append(self.num)                                     # 정의 한 변수(num)를 리스트에 반복 저장
            self.num += 1                                                   # 반복하는 횟수 만큼 정의 한 변수(num)에 더하기
        print(self.total[-self.computer:])                                  # 입력 받은 범위 내 숫자 출력

        return self.total, self.num                                         # 저장 된 리스트 및 함수 return

    def Computer_hard_mode(self):                                           # 컴퓨터(어려움) 웹 사이트 내 게임 공식 활용
        print('\n\n----------컴퓨터 차례!!------------')
        if self.num == 1:                                                   # 정의된 변수(num)의 최종 숫자에 따라 리스트 반복 저장 및 변수(num)에 더하기
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 2:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 3:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 4:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 5:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 6:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 7:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 8:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 9:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 10:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 11:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 12:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 13:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 14:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 15:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 16:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 17:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 18:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 19:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 20:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 21:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 22:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 23:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 24:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 25:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 26:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 27:
            self.computer = random.randint(1, 3)
            for a in range(self.computer):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-self.computer:])
        elif self.num == 28:
            for i in range(3):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-3:])
        elif self.num == 29:
            for i in range(2):
                self.total.append(self.num)
                self.num += 1
            print(self.total[-2:])
        elif self.num == 30:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")
        elif self.num == 31:
            self.total.append(self.num)
            self.num += 1
            print("[", self.total[-1], "]")

        return self.total, self.num                                                     # 저장 된 리스트 및 함수 return
